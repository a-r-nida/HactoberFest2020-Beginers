from django.contrib import admin
from .models import UserResult
# Register your models here.
admin.site.register(UserResult)