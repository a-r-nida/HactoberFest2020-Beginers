from django.apps import AppConfig


class PaidConfig(AppConfig):
    name = 'paid'
